Start BackdoorSender.py on the host Computer/Server.
IT MUST BE RUNNING WHEN BACKDOOR.PY GETS OPENED!